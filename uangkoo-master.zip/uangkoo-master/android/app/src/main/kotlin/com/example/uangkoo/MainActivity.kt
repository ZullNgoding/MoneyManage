package com.example.uangkoo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
